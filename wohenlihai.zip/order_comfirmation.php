<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if ($order_id <= 0) {
    header('Location: index.php');
    exit();
}

// Get order details
$stmt = $pdo->prepare("
    SELECT o.*, u.username 
    FROM orders o 
    JOIN users u ON o.user_id = u.user_id 
    WHERE o.order_id = ? AND o.user_id = ?
");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: index.php');
    exit();
}

// Get order items
$stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt->execute([$order_id]);
$items = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Order Confirmation</title>
    <style>
        body { font-family: Arial; background: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; text-align: center; }
        .success-icon { font-size: 60px; color: #28a745; margin-bottom: 20px; }
        h1 { color: #333; }
        .order-number { background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        .total { font-size: 18px; font-weight: bold; color: #e60012; }
        .btn { display: inline-block; background: #e60012; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-icon">✓</div>
        <h1>Order Confirmed!</h1>
        <p>Thank you for your purchase.</p>
        
        <div class="order-number">
            <strong>Order Number:</strong> <?php echo htmlspecialchars($order['order_number']); ?><br>
            <strong>Date:</strong> <?php echo date('d M Y, h:i A', strtotime($order['order_date'])); ?>
        </div>
        
        <h3>Order Items</h3>
        <table>
            <thead>
                <tr><th>Product</th><th>Quantity</th><th>Price</th><th>Subtotal</th></tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>RM <?php echo number_format($item['price'], 2); ?></td>
                    <td>RM <?php echo number_format($item['subtotal'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="total">
            Total Paid: RM <?php echo number_format($order['total_price'], 2); ?>
        </div>
        
        <div style="margin-top: 20px;">
            <p><strong>Points Earned:</strong> <?php echo $order['points_earned']; ?> points</p>
            <p><strong>Points Used:</strong> <?php echo $order['points_used']; ?> points</p>
        </div>
        
        <a href="../products/listing.php" class="btn">Continue Shopping</a>
        <a href="../orders/history.php" style="margin-left: 15px;">View Order History</a>
    </div>
</body>
</html>