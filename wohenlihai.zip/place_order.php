<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get cart items
$stmt = $pdo->prepare("
    SELECT c.*, p.name, p.price, p.stock 
    FROM cart c 
    JOIN products p ON c.product_id = p.product_id 
    WHERE c.user_id = ?
");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll();

if (empty($cart_items)) {
    header('Location: index.php');
    exit();
}

$subtotal = 0;
foreach ($cart_items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

$stmt = $pdo->prepare("SELECT point FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$user_points = $user['point'] ?? 0;

$shipping_address = $_POST['shipping_address'] ?? '';
$contact_phone = $_POST['contact_phone'] ?? '';
$points_to_use = (int)($_POST['points_to_use'] ?? 0);
$max_points_to_use = min($user_points, $subtotal * 100);

$error = '';

if (empty($shipping_address)) {
    $error = "Shipping address is required";
} elseif (empty($contact_phone)) {
    $error = "Contact phone is required";
} elseif ($points_to_use > $max_points_to_use) {
    $error = "Invalid points amount";
}

if ($error) {
    $_SESSION['checkout_error'] = $error;
    header('Location: checkout.php');
    exit();
}

// 积分计算：10 points = RM 0.10
$points_discount = $points_to_use / 100;
$final_total = $subtotal - $points_discount;
$points_earned = floor($final_total);  // 每RM1赚1分
$order_number = 'ORD' . date('Ymd') . rand(1000, 9999);

try {
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("
        INSERT INTO orders (order_number, user_id, total_price, points_used, points_earned, shipping_address, contact_phone, order_status, payment_status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', 'pending')
    ");
    $stmt->execute([$order_number, $user_id, $final_total, $points_to_use, $points_earned, $shipping_address, $contact_phone]);
    $order_id = $pdo->lastInsertId();
    
    foreach ($cart_items as $item) {
        $subtotal_item = $item['price'] * $item['quantity'];
        $stmt = $pdo->prepare("
            INSERT INTO order_items (order_id, product_id, product_name, quantity, price, subtotal) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$order_id, $item['product_id'], $item['name'], $item['quantity'], $item['price'], $subtotal_item]);
        
        $stmt = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE product_id = ?");
        $stmt->execute([$item['quantity'], $item['product_id']]);
    }
    
    $new_points = $user_points - $points_to_use + $points_earned;
    $stmt = $pdo->prepare("UPDATE users SET point = ? WHERE user_id = ?");
    $stmt->execute([$new_points, $user_id]);
    
    $stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
    $stmt->execute([$user_id]);
    
    $pdo->commit();
    
    // 显示成功页面
    echo "<!DOCTYPE html>";
    echo "<html><head><title>Order Confirmed</title>";
    echo "<style>
        body { font-family: Arial; background: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; text-align: center; }
        .success { color: #28a745; font-size: 60px; margin-bottom: 20px; }
        h1 { color: #333; margin-bottom: 10px; }
        .order-number { background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .btn { display: inline-block; background: #e60012; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; margin: 10px; }
        .btn-gray { background: #666; }
    </style>";
    echo "</head><body>";
    echo "<div class='container'>";
    echo "<div class='success'>✓</div>";
    echo "<h1>Order Confirmed!</h1>";
    echo "<p>Thank you for your purchase.</p>";
    echo "<div class='order-number'>";
    echo "<strong>Order Number:</strong> " . htmlspecialchars($order_number) . "<br>";
    echo "<strong>Total Paid:</strong> RM " . number_format($final_total, 2) . "<br>";
    echo "<strong>Points Earned:</strong> " . $points_earned . " points<br>";
    echo "<strong>Points Used:</strong> " . $points_to_use . " points (RM " . number_format($points_discount, 2) . " discount)";
    echo "</div>";
    echo "<a href='../products/listing.php' class='btn btn-gray'>Continue Shopping</a>";
    echo "<a href='../orders/history.php' class='btn'>View Orders</a>";
    echo "</div></body></html>";
    exit();
    
} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['checkout_error'] = "Order failed: " . $e->getMessage();
    header('Location: checkout.php');
    exit();
}
?>