<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get cart items
$stmt = $pdo->prepare("
    SELECT c.*, p.name, p.price, p.stock 
    FROM cart c 
    JOIN products p ON c.product_id = p.product_id 
    WHERE c.user_id = ?
");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll();

if (empty($cart_items)) {
    header('Location: index.php');
    exit();
}

$subtotal = 0;
foreach ($cart_items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

// Get user points
$stmt = $pdo->prepare("SELECT point FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$user_points = $user['point'] ?? 0;
$max_points_to_use = min($user_points, $subtotal * 100);

$error = $_SESSION['checkout_error'] ?? '';
unset($_SESSION['checkout_error']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <style>
        body { font-family: Arial; background: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; display: flex; gap: 30px; }
        .checkout-form { flex: 2; background: white; padding: 20px; border-radius: 10px; }
        .order-summary { flex: 1; background: white; padding: 20px; border-radius: 10px; height: fit-content; }
        h2 { color: #333; border-bottom: 2px solid #e60012; padding-bottom: 10px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
        .btn-place-order { background: #e60012; color: white; padding: 15px; border: none; border-radius: 5px; cursor: pointer; width: 100%; font-size: 16px; }
        .error { background: #ffebee; color: #c62828; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
        .points-box { background: #fff3e0; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .summary-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
        .summary-total { font-size: 18px; font-weight: bold; color: #e60012; margin-top: 10px; padding-top: 10px; border-top: 2px solid #ddd; }
    </style>
</head>
<body>
    <div class="container">
        <div class="checkout-form">
            <h2>Checkout</h2>
            
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="place_order.php">
                <div class="form-group">
                    <label>Shipping Address</label>
                    <textarea name="shipping_address" rows="3" required placeholder="Enter your full address"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Contact Phone</label>
                    <input type="tel" name="contact_phone" required placeholder="012-3456789">
                </div>
                
                <div class="points-box">
                    <strong>💰 Your Points: <?php echo number_format($user_points); ?></strong><br>
                    <small>10 points = RM 0.10 discount | 100 points = RM 1.00</small><br><br>
                    <label>Use points:</label>
                    <input type="number" name="points_to_use" min="0" max="<?php echo $max_points_to_use; ?>" value="0" id="points_input" onchange="updateTotal()">
                    <div id="points_preview"></div>
                </div>
                
                <button type="submit" class="btn-place-order">Place Order</button>
            </form>
        </div>
        
        <div class="order-summary">
            <h2>Order Summary</h2>
            <?php foreach ($cart_items as $item): ?>
                <div class="summary-item">
                    <span><?php echo htmlspecialchars($item['name']); ?> x <?php echo $item['quantity']; ?></span>
                    <span>RM <?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                </div>
            <?php endforeach; ?>
            <div class="summary-item">
                <strong>Subtotal</strong>
                <strong id="subtotal">RM <?php echo number_format($subtotal, 2); ?></strong>
            </div>
            <div id="discount_row" class="summary-item" style="display:none;">
                <span>Points Discount</span>
                <span id="discount_amount">-RM 0.00</span>
            </div>
            <div class="summary-total">
                <span>Total</span>
                <span id="total_amount">RM <?php echo number_format($subtotal, 2); ?></span>
            </div>
        </div>
    </div>
    
    <script>
        const subtotal = <?php echo $subtotal; ?>;
        
        function updateTotal() {
            let points = parseInt(document.getElementById('points_input').value) || 0;
            let discount = points / 100;
            let newTotal = subtotal - discount;
            
            if (discount > 0) {
                document.getElementById('discount_row').style.display = 'flex';
                document.getElementById('discount_amount').innerText = '-RM ' + discount.toFixed(2);
            } else {
                document.getElementById('discount_row').style.display = 'none';
            }
            document.getElementById('total_amount').innerText = 'RM ' + newTotal.toFixed(2);
        }
    </script>
</body>
</html>