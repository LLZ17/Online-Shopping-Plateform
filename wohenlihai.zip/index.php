<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get cart items
$stmt = $pdo->prepare("
    SELECT c.*, p.name, p.price, p.product_image, p.stock 
    FROM cart c 
    JOIN products p ON c.product_id = p.product_id 
    WHERE c.user_id = ?
");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll();

// Calculate total
$total = 0;
foreach ($cart_items as $item) {
    $total += $item['price'] * $item['quantity'];
}

// Handle remove from cart
if (isset($_GET['remove'])) {
    $cart_id = (int)$_GET['remove'];
    $stmt = $pdo->prepare("DELETE FROM cart WHERE cart_id = ? AND user_id = ?");
    $stmt->execute([$cart_id, $user_id]);
    header('Location: index.php');
    exit();
}

// Handle update quantity
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $cart_id => $qty) {
        $qty = max(1, (int)$qty);
        $stmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE cart_id = ? AND user_id = ?");
        $stmt->execute([$qty, $cart_id, $user_id]);
    }
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shopping Cart</title>
    <style>
        body { font-family: Arial; background: #f5f5f5; margin: 0; padding: 20px; }
        .nav-menu { background: #333; padding: 10px 20px; margin-bottom: 20px; text-align: center; border-radius: 5px; }
        .nav-menu a { color: white; margin: 0 15px; text-decoration: none; }
        .nav-menu a:hover { color: #e60012; }
        .nav-menu a.active { color: #e60012; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        h1 { color: #333; border-bottom: 2px solid #e60012; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #ddd; }
        .qty-input { width: 60px; padding: 5px; text-align: center; }
        .remove-link { color: #e60012; text-decoration: none; }
        .total { font-size: 20px; font-weight: bold; text-align: right; margin-top: 20px; }
        .btn-checkout { background: #e60012; color: white; padding: 12px 30px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; text-decoration: none; display: inline-block; }
        .btn-update { background: #666; color: white; padding: 8px 20px; border: none; border-radius: 5px; cursor: pointer; }
        .empty-cart { text-align: center; padding: 50px; color: #999; }
        .cart-actions { margin-top: 20px; display: flex; justify-content: space-between; align-items: center; }
    </style>
</head>
<body>
    <!-- 导航菜单 -->
    <div class="nav-menu">
        <a href="../index.php">🏠 Home</a>
        <a href="../products/listing.php">🛍️ Products</a>
        <a href="index.php" class="active">🛒 Cart</a>
        <a href="../orders/history.php">📦 Orders</a>
        <?php if(isset($_SESSION['username'])): ?>
            <a href="../profile.php">👤 <?php echo htmlspecialchars($_SESSION['username']); ?></a>
            <a href="../logout.php" style="color: #e60012;">🚪 Logout</a>
        <?php else: ?>
            <a href="../login.php">🔑 Login</a>
        <?php endif; ?>
    </div>
    
    <div class="container">
        <h1>Shopping Cart</h1>
        
        <?php if (empty($cart_items)): ?>
            <div class="empty-cart">
                <p>Your cart is empty.</p>
                <a href="../products/listing.php" class="btn-checkout" style="background: #666;">Continue Shopping</a>
            </div>
        <?php else: ?>
            <form method="POST">
                <table>
                    <thead>
                        <tr><th>Product</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th></th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart_items as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                <td>RM <?php echo number_format($item['price'], 2); ?></td>
                                <td>
                                    <input type="number" name="quantity[<?php echo $item['cart_id']; ?>]" 
                                           value="<?php echo $item['quantity']; ?>" min="1" 
                                           max="<?php echo $item['stock']; ?>" class="qty-input">
                                </td>
                                <td>RM <?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                <td><a href="?remove=<?php echo $item['cart_id']; ?>" class="remove-link" onclick="return confirm('Remove item?')">Remove</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="cart-actions">
                    <button type="submit" name="update_cart" class="btn-update">Update Cart</button>
                    <div class="total">Total: RM <?php echo number_format($total, 2); ?></div>
                </div>
                <div style="text-align: right; margin-top: 20px;">
                    <a href="../products/listing.php" class="btn-checkout" style="background: #666; margin-right: 10px;">← Continue Shopping</a>
                    <a href="checkout.php" class="btn-checkout">Proceed to Checkout →</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>